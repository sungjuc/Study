/*
 * File: main.cpp
 * --------------
 * This is an empty C++ source file.
 */

#include <iostream>
#include "console.h"

using namespace std;

int main() {
    
    return 0;
}
